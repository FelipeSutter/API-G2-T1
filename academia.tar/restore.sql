--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE academia;
--
-- Name: academia; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE academia WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE academia OWNER TO postgres;

\connect academia

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: instrutor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.instrutor (
    codigoinstrutor integer NOT NULL,
    rg bigint,
    nome character varying(255)
);


ALTER TABLE public.instrutor OWNER TO postgres;

--
-- Name: instrutor_codigoinstrutor_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.instrutor_codigoinstrutor_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.instrutor_codigoinstrutor_seq OWNER TO postgres;

--
-- Name: instrutor_codigoinstrutor_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.instrutor_codigoinstrutor_seq OWNED BY public.instrutor.codigoinstrutor;


--
-- Name: instrutor codigoinstrutor; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instrutor ALTER COLUMN codigoinstrutor SET DEFAULT nextval('public.instrutor_codigoinstrutor_seq'::regclass);


--
-- Data for Name: instrutor; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3321.dat

--
-- Name: instrutor_codigoinstrutor_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.instrutor_codigoinstrutor_seq', 1, false);


--
-- Name: instrutor instrutor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instrutor
    ADD CONSTRAINT instrutor_pkey PRIMARY KEY (codigoinstrutor);


--
-- Name: instrutor instrutor_rg_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instrutor
    ADD CONSTRAINT instrutor_rg_key UNIQUE (rg);


--
-- PostgreSQL database dump complete
--

